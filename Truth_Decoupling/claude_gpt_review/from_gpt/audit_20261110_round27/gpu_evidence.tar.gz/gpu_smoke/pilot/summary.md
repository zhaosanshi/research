# E43 judge-free summary (pilot included)

| family | arm | layer | n | changed | refusal before → after | = side prompt (baseline =) | unfinished | write prefill / decode (‖Δh‖/‖h‖) | final CE plus / minus | endpoint gap | pairs | complete |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C | caut_to_conf | 16 | 3 | 0 | 1 → 1 | 1 (1) | 0 | 0.032 / 0.022 | 1.49 / 0.52 | -0.015 | 3 | no (pilot) |
| C | conf_to_caut | 16 | 3 | 0 | 0 → 0 | 1 (1) | 0 | 0.029 / 0.019 | 1.49 / 0.52 | -0.015 | 3 | no (pilot) |
| C | main | 16 | 3 | 0 | 1 → 1 | 3 (3) | 0 | 0.030 / 0.021 | 1.49 / 0.52 | -0.015 | 3 | no (pilot) |
| C | md_main | 16 | 3 | 1 | 1 → 1 | 2 (3) | 0 | 0.063 / 0.041 | 1.49 / 0.52 | -0.015 | 3 | no (pilot) |
| C | none | 16 | 3 | 0 | 1 → 1 | 3 (3) | 0 | — / — | 1.49 / 0.52 | -0.015 | 3 | no (pilot) |
| C | random_main | 16 | 3 | 0 | 1 → 1 | 3 (3) | 0 | 0.030 / 0.021 | 1.49 / 0.52 | -0.015 | 3 | no (pilot) |
| C | to_conf | 16 | 3 | 0 | 1 → 1 | 1 (1) | 0 | 0.031 / 0.022 | 1.49 / 0.52 | -0.015 | 3 | no (pilot) |
| E | main | 16 | 3 | 0 | 1 → 1 | 2 (2) | 0 | 0.055 / 0.036 | 2.60 / 0.44 | 0.021 | 3 | no (pilot) |
| E | md_main | 16 | 3 | 1 | 1 → 1 | 2 (2) | 0 | 0.113 / 0.145 | 2.60 / 0.44 | 0.021 | 3 | no (pilot) |
| E | none | 16 | 3 | 0 | 1 → 1 | 2 (2) | 0 | — / — | 2.60 / 0.44 | 0.021 | 3 | no (pilot) |
| E | perq | 16 | 3 | 0 | 1 → 1 | 2 (2) | 0 | 0.055 / 0.036 | 2.60 / 0.44 | 0.021 | 3 | no (pilot) |
| E | random_main | 16 | 3 | 0 | 1 → 1 | 2 (2) | 0 | 0.055 / 0.036 | 2.60 / 0.44 | 0.021 | 3 | no (pilot) |
| E | recover | 16 | 3 | 0 | 1 → 1 | 2 (2) | 0 | 0.052 / 0.032 | 2.60 / 0.44 | 0.021 | 3 | no (pilot) |
