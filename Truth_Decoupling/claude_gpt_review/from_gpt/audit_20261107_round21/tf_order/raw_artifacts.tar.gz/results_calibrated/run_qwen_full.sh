#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=/workspace/Truth_Decoupling
CODE_PATH=$TASK_ROOT/review_r21_e38_v2_codex_20261107
RUN_PATH=$TASK_ROOT/results_r21_e38_calibrated_codex_20261107/qwen3-8b/full192
CAL_PATH=$TASK_ROOT/results_r21_e38_calibrated_codex_20261107/qwen3-8b/train_calibration
mkdir -p "$RUN_PATH"
for PHASE in prepare collect report; do
  if python "$CODE_PATH/scripts/e38_tf_commitment_order.py" "$PHASE" --model qwen3-8b --source-run "$TASK_ROOT/results_r20_codex_20261107/tf_ability/qwen3-8b/tf_ability_full" --run-dir "$RUN_PATH" --dose-mode train_relative --calibration-run "$CAL_PATH" > "$RUN_PATH/$PHASE.log" 2>&1; then
    echo 0 > "$RUN_PATH/$PHASE.exit"
  else
    status=$?
    echo "$status" > "$RUN_PATH/$PHASE.exit"
    exit "$status"
  fi
done
