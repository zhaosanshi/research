#!/usr/bin/env bash
set -euo pipefail
MODEL=$1
TASK_ROOT=/workspace/Truth_Decoupling
CODE_PATH=$TASK_ROOT/review_r21_e39_v1_codex_20261107
RUN_PATH=$TASK_ROOT/results_r21_e39_codex_20261107/$MODEL/train92_neighbor
mkdir -p "$RUN_PATH"
for PHASE in prepare calibrate check; do
  if python "$CODE_PATH/scripts/e39_neighbor_c_function.py" "$PHASE" --model "$MODEL" --e-run "$TASK_ROOT/results_e34_codex_20261107/$MODEL/full92_ep3" --c-run "$TASK_ROOT/results_r20_codex_20261107/qa_ability/$MODEL/qa_ability_full" --e37-calibration-dir "$TASK_ROOT/results_r21_source_order_codex_20261107/$MODEL/calibration" --run-dir "$RUN_PATH" > "$RUN_PATH/$PHASE.log" 2>&1; then
    echo 0 > "$RUN_PATH/$PHASE.exit"
  else
    status=$?
    echo "$status" > "$RUN_PATH/$PHASE.exit"
    exit "$status"
  fi
done
