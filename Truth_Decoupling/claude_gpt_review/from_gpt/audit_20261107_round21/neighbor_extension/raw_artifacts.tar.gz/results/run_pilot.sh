#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=/workspace/Truth_Decoupling
CODE_PATH=$TASK_ROOT/review_r21_e40_v1_codex_20261107
PARENT_PATH=$TASK_ROOT/results_r21_source_order_codex_20261107/llama3.1-8b/reference_locked
RUN_PATH=$TASK_ROOT/results_r21_e40_codex_20261107/llama3.1-8b/pilot3
mkdir -p "$RUN_PATH"
for PHASE in prepare generate judge; do
  if python "$CODE_PATH/scripts/e40_neighbor_c_extension.py" "$PHASE" --source-run "$TASK_ROOT/results_qa_das_v1u/llama3.1-8b/full" --e-run "$TASK_ROOT/results_e34_codex_20261107/llama3.1-8b/full92_ep3" --c-run "$TASK_ROOT/results_r20_codex_20261107/qa_ability/llama3.1-8b/qa_ability_full" --parent-run "$PARENT_PATH" --parent-grades "$PARENT_PATH/tune_scored_items.json" --controls-judge-cache "$PARENT_PATH/judge_cache" --e39-run "$TASK_ROOT/results_r21_e39_codex_20261107/llama3.1-8b/train92_neighbor" --run-dir "$RUN_PATH" --pilot > "$RUN_PATH/$PHASE.log" 2>&1; then
    echo 0 > "$RUN_PATH/$PHASE.exit"
  else
    status=$?
    echo "$status" > "$RUN_PATH/$PHASE.exit"
    exit "$status"
  fi
done
