#!/usr/bin/env python3
"""Inference-only source-interchange controls on the existing tuning split.

This is a new deployment diagnostic of frozen original-DAS directions, not a
claim of reproducing CDAS or of having trained generation-specific DAS. The
truth-oriented source instruction never receives a reference answer. All five
conditions and all requested questions are reported; no test-set phase exists.
"""
import argparse
import copy
import json
from pathlib import Path
import shutil

import torch

import common  # noqa: F401
import e25_qa_das as qa
import e27_qa_generation as adapter_script
from core.qa_generation_adapter import implementation_identity
from core.qa_precision import fp32_output_projection
from core.qa_source_interchange import (PROTOCOL, SourceInterchangeDecoder, greedy_source_generate,
                                        token_digest)
from core.readout import rule_abstains


SOURCE_SYSTEM = ("Answer factual questions truthfully. Correct false premises rather than accepting them. "
                 "Give a short, direct answer of a few words. If you do not know the answer, say 'I don't know'.")
CONDITIONS = ('baseline', 'source_only', 'equal_logit_mix', 'source_das_swap', 'source_random_swap')


def prompt_tokens(bundle, cfg, question):
    """The sole text input to either forward stream is a question, never gold."""
    if not isinstance(question, str) or not question:
        raise ValueError('a nonempty question is required')
    user = cfg['qa_user'].format(question=question)
    base = bundle.build_chat(cfg['qa_system'], user)
    source = bundle.build_chat(SOURCE_SYSTEM, user)
    ids = []
    for text in (base, source):
        inputs = bundle.encode(text)
        if inputs['input_ids'].shape[0] != 1 or not bool(inputs['attention_mask'].all()):
            raise ValueError('single-question prompts must be unpadded')
        ids.append(inputs['input_ids'][0].tolist())
    return ids


def cache_reference_check(bundle, base, source, layer, w, accepted_tokens, steps=3):
    """Replay identical actual past IDs; compare two implementations before scaling up."""
    cached = SourceInterchangeDecoder(bundle, base, source, mode='source_interchange', layer=layer,
                                      direction=w, use_cache=True)
    full = SourceInterchangeDecoder(bundle, base, source, mode='source_interchange', layer=layer,
                                    direction=w, use_cache=False)
    dtype = next(bundle.model.parameters()).dtype
    tolerance = .10 if dtype in (torch.bfloat16, torch.float16) else 1e-5
    rows = []
    for token in accepted_tokens[:steps]:
        a, ta = cached.next_logits(); b, tb = full.next_logits()
        diff = float((a - b).abs().max())
        same_top = int(a.argmax()) == int(b.argmax())
        rows.append({'step': len(cached.history), 'max_absolute_logit_difference': diff,
                     'tolerance': tolerance, 'top1_equal': same_top,
                     'accepted_prefix_ids_equal': ta['accepted_prefix_ids'] == tb['accepted_prefix_ids'],
                     'cached_writes': len(ta['writes']), 'full_recomputed_writes': len(tb['writes'])})
        if diff > tolerance or not same_top:
            raise RuntimeError('cached/full source interchange disagrees: ' + json.dumps(rows[-1]))
        cached.accept(token); full.accept(token)
    return rows


def inputs(args):
    ns, meta, bank, prepared = adapter_script.source_run(args.source_run)
    frozen = qa.selection(ns, meta)
    selected = frozen['selected']['qa_das']
    if selected is None:
        raise ValueError('source run has no previously frozen original-DAS layer')
    layer = selected['layer']
    questions = prepared['splits']['tune']
    if args.pair_ids:
        wanted = list(args.pair_ids)
        if len(wanted) != len(set(wanted)) or not set(wanted) <= {q['pair_id'] for q in questions}:
            raise ValueError('pilot IDs must be unique tuning questions')
        questions = [q for q in questions if q['pair_id'] in set(wanted)]
    elif args.phase in ('check', 'judge-check'):
        questions = questions[:3]
    if not questions:
        raise ValueError('empty tuning cohort')
    w = torch.as_tensor(bank['E_qa_das_L%d' % layer]).float().clone()
    generator = torch.Generator(device='cpu').manual_seed(args.seed + layer)
    random_w = torch.nn.functional.normalize(torch.randn(meta['hidden_size'], generator=generator), dim=0)
    code = implementation_identity()
    code['entry_script_sha256'] = qa.digest(Path(__file__))
    identity = {'protocol': PROTOCOL, 'model': meta['model'], 'source': adapter_script.source_identity(ns, meta, [layer]),
                'source_selection_sha256': qa.digest(ns.run_dir / 'selection.json'),
                'layer': layer, 'layer_choice': 'unchanged existing tuning-frozen original-DAS layer',
                'source_system': SOURCE_SYSTEM, 'base_system': meta['config']['qa_system'],
                'user_template': meta['config']['qa_user'], 'max_new_tokens': meta['config']['max_new_tokens'],
                'batch_size': 1, 'alpha': 1.0, 'fixed_global_center': False,
                'conditions': list(CONDITIONS), 'seed': args.seed, 'random_seed': args.seed + layer,
                'question_ids': [q['pair_id'] for q in questions], 'split': 'tune',
                'training_called': False, 'extra_content_adaptation': False, 'gold_used_at_inference': False,
                'same_generated_prefix_token_ids': True, 'independent_kv_streams': True,
                'direction_sha256': qa.fingerprint(w.tolist()), 'random_direction_sha256': qa.fingerprint(random_w.tolist()),
                'implementation': code, 'exploratory_previously_exposed_tuning_set': True,
                'source_variable': 'fixed instruction policy; source answer is not guaranteed true'}
    return ns, meta, bank, prepared, questions, layer, w, random_w, identity


def generate(args, state, bundle=None):
    ns, meta, bank, prepared, questions, layer, w, random_w, identity = state
    args.run_dir.mkdir(parents=True, exist_ok=True)
    filename = 'check.json' if args.phase == 'check' else 'tune.json'
    path = args.run_dir / filename
    if path.exists():
        existing = qa.read(path)
        if existing.get('identity') != identity:
            raise ValueError('existing source-interchange run differs; preserve it and use a new directory')
        if existing.get('completed'):
            return existing
        raise ValueError('partial diagnostic exists; preserve it and use a new directory')
    if bundle is None:
        bundle = qa.open_bundle(meta, prepared)
    qa.verify_bundle(bundle, meta, prepared)
    versions = [(p, p._version, p.requires_grad) for p in bundle.model.parameters()]
    choices = [{'name': name, 'kind': 'baseline' if name == 'baseline' else 'E',
                'uses_reference_answer': False, 'eligible_for_selection': False} for name in CONDITIONS]
    result = {'protocol': PROTOCOL, 'model': meta['model'], 'identity': identity,
              'bank_protocol_fingerprint': qa.fingerprint(identity), 'protocol_fingerprint': qa.fingerprint(identity),
              'split': 'tune', 'pilot': args.phase == 'check' or bool(args.pair_ids),
              'wiring_pilot': args.phase == 'check', 'diagnostic_only': False,
              'conditions': list(CONDITIONS), 'condition_specs': choices, 'evaluations': [],
              'E': {'method': 'original-DAS frozen direction with live same-prefix source coordinate'},
              'C': {'enabled': False}, 'completed': False}
    snapshots = args.run_dir / 'code_snapshot'
    code_root = Path(__file__).resolve().parents[1]
    for relative, expected in identity['implementation']['files'].items():
        target = snapshots / relative; target.parent.mkdir(parents=True, exist_ok=True)
        if qa.digest(code_root / relative) != expected:
            raise RuntimeError('source code changed before diagnostic execution')
        shutil.copyfile(code_root / relative, target)
    shutil.copyfile(__file__, snapshots / 'scripts/e29_qa_source_interchange.py')
    with fp32_output_projection(bundle):
        for q in questions:
            base, source = prompt_tokens(bundle, meta['config'], q['question'])
            row = {**copy.deepcopy(q), 'outputs': {}, 'finished': {}, 'rule_abstain': {},
                   'generation_token_ids': {}, 'trace': {}, 'cache_reference_checks': {},
                   'prompt_token_ids': {'base': base, 'source': source}}
            for name in CONDITIONS:
                mode = 'source_interchange' if name.endswith('_swap') else name
                direction = random_w if name == 'source_random_swap' else w
                output = greedy_source_generate(bundle, base, source, mode=mode, layer=layer, direction=direction,
                                                 max_new_tokens=identity['max_new_tokens'])
                row['outputs'][name] = output['output']; row['finished'][name] = output['finished']
                row['rule_abstain'][name] = bool(rule_abstains(output['output']))
                row['generation_token_ids'][name] = output['token_ids']; row['trace'][name] = output['trace']
                if name.endswith('_swap') and args.phase == 'check':
                    row['cache_reference_checks'][name] = cache_reference_check(
                        bundle, base, source, layer, direction, output['token_ids'])
                print('SOURCE_INTERCHANGE', meta['model'], q['pair_id'], name, repr(output['output']), flush=True)
            result['evaluations'].append(row)
            qa.save(path, result)
    if any(p._version != version or p.requires_grad != flag for p, version, flag in versions):
        raise RuntimeError('inference-only diagnostic changed base-model parameters')
    if qa.fingerprint(w.tolist()) != identity['direction_sha256']:
        raise RuntimeError('frozen original-DAS direction changed')
    result.update(completed=True, base_parameters_unchanged=True, frozen_direction_unchanged=True)
    qa.save(path, result)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('phase', choices=('check', 'generate-tune', 'judge-check', 'judge-tune'))
    p.add_argument('--source-run', type=Path, required=True)
    p.add_argument('--run-dir', type=Path, required=True)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--pair-ids', nargs='+')
    p.add_argument('--judge-exp', default='E4_qa')
    args = p.parse_args()
    state = inputs(args)
    if args.phase.startswith('judge-'):
        _, meta, _, _, _, _, _, _, identity = state
        args.model = meta['model']; adapter_script.validate_judge_experiment(args.judge_exp)
        stem = args.phase.split('-', 1)[1]
        qa.judge(args, {**meta, 'protocol_fingerprint': qa.fingerprint(identity)}, stem + '.json', stem + '_scored')
    else:
        generate(args, state)


if __name__ == '__main__':
    main()
