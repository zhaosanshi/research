# E26 同实际作答率方法比较

精确配额表是离线批量筛题评估：排序分不看正确性或参考答案，QA候选是否实质回答由看过参考的外部语义标注确定。A/B一律可选，只排除C；不宣称线上可无参考精确填满K。
冻结门槛策略按分数发出候选，再由离线语义标注统计实际实质作答率，不保证达到固定配额。
QA分母为固定实质参考题；不够配额标不可行，未决判分不出表。

PILOT ONLY — 线路检查，不作效果结论。
本运行实际评估任务：qa。


## qa / 目标 25%

| 方法 | 实际回答 | 答对 | 已回答准确率 | 95%区间 | 状态 |
|---|---:|---:|---:|---|---|
| baseline_commitment | 0/3 | 0 | — | — | undefined_zero_answers |
| baseline_simple | 0/3 | 0 | — | — | undefined_zero_answers |
| baseline_random | 0/3 | 0 | — | — | undefined_zero_answers |
| das_E | 0/3 | 0 | — | — | undefined_zero_answers |
| das_C | 0/3 | 0 | — | — | undefined_zero_answers |
| das_EC | 0/3 | 0 | — | — | undefined_zero_answers |
| md_E | 0/3 | 0 | — | — | undefined_zero_answers |
| md_C | 0/3 | 0 | — | — | undefined_zero_answers |
| md_EC | 0/3 | 0 | — | — | undefined_zero_answers |
| das_E_simple | 0/3 | 0 | — | — | undefined_zero_answers |
| das_C_simple | 0/3 | 0 | — | — | undefined_zero_answers |
| das_EC_simple | 0/3 | 0 | — | — | undefined_zero_answers |
| md_E_simple | 0/3 | 0 | — | — | undefined_zero_answers |
| md_C_simple | 0/3 | 0 | — | — | undefined_zero_answers |
| md_EC_simple | 0/3 | 0 | — | — | undefined_zero_answers |

组合与单方向／简单筛题的直接配对差；下表统一为“组合减对照”。

| 组合 | 对照 | 已回答准确率差 | 95%区间 | 固定交付精确p | 状态 |
|---|---|---:|---|---:|---|
| das_EC | baseline_commitment | — | — | 1.0000 | undefined_zero_answers |
| das_EC | baseline_simple | — | — | 1.0000 | undefined_zero_answers |
| das_EC | baseline_random | — | — | 1.0000 | undefined_zero_answers |
| das_EC | das_E | — | — | 1.0000 | undefined_zero_answers |
| das_EC | das_C | — | — | 1.0000 | undefined_zero_answers |
| das_EC | das_E_simple | — | — | 1.0000 | undefined_zero_answers |
| das_EC | das_C_simple | — | — | 1.0000 | undefined_zero_answers |
| das_EC_simple | baseline_commitment | — | — | 1.0000 | undefined_zero_answers |
| das_EC_simple | baseline_simple | — | — | 1.0000 | undefined_zero_answers |
| das_EC_simple | baseline_random | — | — | 1.0000 | undefined_zero_answers |
| das_EC_simple | das_E | — | — | 1.0000 | undefined_zero_answers |
| das_EC_simple | das_C | — | — | 1.0000 | undefined_zero_answers |
| das_EC_simple | das_E_simple | — | — | 1.0000 | undefined_zero_answers |
| das_EC_simple | das_C_simple | — | — | 1.0000 | undefined_zero_answers |
| md_EC | baseline_commitment | — | — | 1.0000 | undefined_zero_answers |
| md_EC | baseline_simple | — | — | 1.0000 | undefined_zero_answers |
| md_EC | baseline_random | — | — | 1.0000 | undefined_zero_answers |
| md_EC | md_E | — | — | 1.0000 | undefined_zero_answers |
| md_EC | md_C | — | — | 1.0000 | undefined_zero_answers |
| md_EC | md_E_simple | — | — | 1.0000 | undefined_zero_answers |
| md_EC | md_C_simple | — | — | 1.0000 | undefined_zero_answers |
| md_EC_simple | baseline_commitment | — | — | 1.0000 | undefined_zero_answers |
| md_EC_simple | baseline_simple | — | — | 1.0000 | undefined_zero_answers |
| md_EC_simple | baseline_random | — | — | 1.0000 | undefined_zero_answers |
| md_EC_simple | md_E | — | — | 1.0000 | undefined_zero_answers |
| md_EC_simple | md_C | — | — | 1.0000 | undefined_zero_answers |
| md_EC_simple | md_E_simple | — | — | 1.0000 | undefined_zero_answers |
| md_EC_simple | md_C_simple | — | — | 1.0000 | undefined_zero_answers |

冻结调参门槛后的实际测试表现（不强制达到目标配额）：

| 方法 | 实际作答率 | 实际回答数 | 答对数 | 已回答准确率 |
|---|---:|---:|---:|---:|
| baseline_commitment | 0.0000 | 0 | 0 | — |
| baseline_simple | 0.0000 | 0 | 0 | — |
| baseline_random | 0.0000 | 0 | 0 | — |
| das_E | 0.0000 | 0 | 0 | — |
| das_C | 0.0000 | 0 | 0 | — |
| das_EC | 0.0000 | 0 | 0 | — |
| md_E | 0.0000 | 0 | 0 | — |
| md_C | 0.0000 | 0 | 0 | — |
| md_EC | 0.0000 | 0 | 0 | — |
| das_E_simple | 0.0000 | 0 | 0 | — |
| das_C_simple | 0.0000 | 0 | 0 | — |
| das_EC_simple | 0.0000 | 0 | 0 | — |
| md_E_simple | 0.0000 | 0 | 0 | — |
| md_C_simple | 0.0000 | 0 | 0 | — |
| md_EC_simple | 0.0000 | 0 | 0 | — |

## qa / 目标 50%

| 方法 | 实际回答 | 答对 | 已回答准确率 | 95%区间 | 状态 |
|---|---:|---:|---:|---|---|
| baseline_commitment | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| baseline_simple | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| baseline_random | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| das_E | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| das_C | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| das_EC | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| md_E | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| md_C | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| md_EC | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| das_E_simple | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| das_C_simple | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| das_EC_simple | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| md_E_simple | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| md_C_simple | 1/3 | 1 | 1.0000 | — | infeasible_resamples |
| md_EC_simple | 1/3 | 1 | 1.0000 | — | infeasible_resamples |

组合与单方向／简单筛题的直接配对差；下表统一为“组合减对照”。

| 组合 | 对照 | 已回答准确率差 | 95%区间 | 固定交付精确p | 状态 |
|---|---|---:|---|---:|---|
| das_EC | baseline_commitment | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | baseline_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | baseline_random | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | das_E | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | das_C | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | das_E_simple | 0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | das_C_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | baseline_commitment | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | baseline_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | baseline_random | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | das_E | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | das_C | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | das_E_simple | 0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | das_C_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | baseline_commitment | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | baseline_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | baseline_random | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | md_E | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | md_C | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | md_E_simple | 0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | md_C_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | baseline_commitment | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | baseline_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | baseline_random | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | md_E | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | md_C | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | md_E_simple | 0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | md_C_simple | -0.0000 | — | 1.0000 | infeasible_resamples |

冻结调参门槛后的实际测试表现（不强制达到目标配额）：

| 方法 | 实际作答率 | 实际回答数 | 答对数 | 已回答准确率 |
|---|---:|---:|---:|---:|
| baseline_commitment | 0.0000 | 0 | 0 | — |
| baseline_simple | 0.0000 | 0 | 0 | — |
| baseline_random | 0.3333 | 1 | 1 | 1.0000 |
| das_E | 0.0000 | 0 | 0 | — |
| das_C | 0.0000 | 0 | 0 | — |
| das_EC | 0.0000 | 0 | 0 | — |
| md_E | 0.0000 | 0 | 0 | — |
| md_C | 0.0000 | 0 | 0 | — |
| md_EC | 0.0000 | 0 | 0 | — |
| das_E_simple | 0.0000 | 0 | 0 | — |
| das_C_simple | 0.0000 | 0 | 0 | — |
| das_EC_simple | 0.0000 | 0 | 0 | — |
| md_E_simple | 0.0000 | 0 | 0 | — |
| md_C_simple | 0.0000 | 0 | 0 | — |
| md_EC_simple | 0.0000 | 0 | 0 | — |

## qa / 目标 75%

| 方法 | 实际回答 | 答对 | 已回答准确率 | 95%区间 | 状态 |
|---|---:|---:|---:|---|---|
| baseline_commitment | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| baseline_simple | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| baseline_random | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| das_E | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| das_C | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| das_EC | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| md_E | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| md_C | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| md_EC | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| das_E_simple | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| das_C_simple | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| das_EC_simple | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| md_E_simple | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| md_C_simple | 2/3 | 1 | 0.5000 | — | infeasible_resamples |
| md_EC_simple | 2/3 | 1 | 0.5000 | — | infeasible_resamples |

组合与单方向／简单筛题的直接配对差；下表统一为“组合减对照”。

| 组合 | 对照 | 已回答准确率差 | 95%区间 | 固定交付精确p | 状态 |
|---|---|---:|---|---:|---|
| das_EC | baseline_commitment | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | baseline_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | baseline_random | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | das_E | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | das_C | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | das_E_simple | 0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC | das_C_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | baseline_commitment | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | baseline_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | baseline_random | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | das_E | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | das_C | -0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | das_E_simple | 0.0000 | — | 1.0000 | infeasible_resamples |
| das_EC_simple | das_C_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | baseline_commitment | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | baseline_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | baseline_random | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | md_E | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | md_C | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | md_E_simple | 0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC | md_C_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | baseline_commitment | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | baseline_simple | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | baseline_random | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | md_E | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | md_C | -0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | md_E_simple | 0.0000 | — | 1.0000 | infeasible_resamples |
| md_EC_simple | md_C_simple | -0.0000 | — | 1.0000 | infeasible_resamples |

冻结调参门槛后的实际测试表现（不强制达到目标配额）：

| 方法 | 实际作答率 | 实际回答数 | 答对数 | 已回答准确率 |
|---|---:|---:|---:|---:|
| baseline_commitment | 0.3333 | 1 | 1 | 1.0000 |
| baseline_simple | 0.3333 | 1 | 1 | 1.0000 |
| baseline_random | 0.3333 | 1 | 1 | 1.0000 |
| das_E | 0.3333 | 1 | 1 | 1.0000 |
| das_C | 0.3333 | 1 | 1 | 1.0000 |
| das_EC | 0.3333 | 1 | 1 | 1.0000 |
| md_E | 0.3333 | 1 | 1 | 1.0000 |
| md_C | 0.3333 | 1 | 1 | 1.0000 |
| md_EC | 0.3333 | 1 | 1 | 1.0000 |
| das_E_simple | 0.3333 | 1 | 1 | 1.0000 |
| das_C_simple | 0.3333 | 1 | 1 | 1.0000 |
| das_EC_simple | 0.3333 | 1 | 1 | 1.0000 |
| md_E_simple | 0.0000 | 0 | 0 | — |
| md_C_simple | 0.3333 | 1 | 1 | 1.0000 |
| md_EC_simple | 0.0000 | 0 | 0 | — |
