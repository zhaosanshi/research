# 固定 E 的原生 C 门控诊断

仅调参集；不能代替 E26 主表或新增测试证据。

门控首词 Yes−No > 0 且候选实际非拒答才交付；对照在同一批题交付完全相同数量。

## tf

| 方法 | 实际回答 | 答对 | 已回答准确率 | 原模型简单筛题答对 | 固定E简单筛题答对 |
|---|---:|---:|---:|---:|---:|
| baseline | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| das_E | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| das_C_a-2_gate_and_answer | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_C_a-2_gate_only | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_C_a-1_gate_and_answer | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_C_a-1_gate_only | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_C_a-0.5_gate_and_answer | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_C_a-0.5_gate_only | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_C_a0_gate_and_answer | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| das_C_a0_gate_only | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| das_C_a0.5_gate_and_answer | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| das_C_a0.5_gate_only | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| das_C_a1_gate_and_answer | 4/6 | 4 | 1.0000 | 4 | {"das_E_simple_threshold": 4, "md_E_simple_threshold": 4} |
| das_C_a1_gate_only | 4/6 | 4 | 1.0000 | 4 | {"das_E_simple_threshold": 4, "md_E_simple_threshold": 4} |
| das_C_a2_gate_and_answer | 5/6 | 4 | 0.8000 | 5 | {"das_E_simple_threshold": 5, "md_E_simple_threshold": 5} |
| das_C_a2_gate_only | 5/6 | 5 | 1.0000 | 5 | {"das_E_simple_threshold": 5, "md_E_simple_threshold": 5} |
| das_EC_a-2_gate_and_answer | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_EC_a-2_gate_only | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_EC_a-1_gate_and_answer | 2/6 | 2 | 1.0000 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_EC_a-1_gate_only | 2/6 | 2 | 1.0000 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_EC_a-0.5_gate_and_answer | 2/6 | 2 | 1.0000 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_EC_a-0.5_gate_only | 2/6 | 2 | 1.0000 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_EC_a0_gate_and_answer | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| das_EC_a0_gate_only | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| das_EC_a0.5_gate_and_answer | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| das_EC_a0.5_gate_only | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| das_EC_a1_gate_and_answer | 4/6 | 4 | 1.0000 | 4 | {"das_E_simple_threshold": 4, "md_E_simple_threshold": 4} |
| das_EC_a1_gate_only | 4/6 | 4 | 1.0000 | 4 | {"das_E_simple_threshold": 4, "md_E_simple_threshold": 4} |
| das_EC_a2_gate_and_answer | 5/6 | 5 | 1.0000 | 5 | {"das_E_simple_threshold": 5, "md_E_simple_threshold": 5} |
| das_EC_a2_gate_only | 5/6 | 5 | 1.0000 | 5 | {"das_E_simple_threshold": 5, "md_E_simple_threshold": 5} |
| md_E | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_C_a-2_gate_and_answer | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_C_a-2_gate_only | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_C_a-1_gate_and_answer | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_C_a-1_gate_only | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_C_a-0.5_gate_and_answer | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_C_a-0.5_gate_only | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_C_a0_gate_and_answer | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_C_a0_gate_only | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_C_a0.5_gate_and_answer | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_C_a0.5_gate_only | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_C_a1_gate_and_answer | 4/6 | 4 | 1.0000 | 4 | {"das_E_simple_threshold": 4, "md_E_simple_threshold": 4} |
| md_C_a1_gate_only | 4/6 | 4 | 1.0000 | 4 | {"das_E_simple_threshold": 4, "md_E_simple_threshold": 4} |
| md_C_a2_gate_and_answer | 5/6 | 5 | 1.0000 | 5 | {"das_E_simple_threshold": 5, "md_E_simple_threshold": 5} |
| md_C_a2_gate_only | 5/6 | 5 | 1.0000 | 5 | {"das_E_simple_threshold": 5, "md_E_simple_threshold": 5} |
| md_EC_a-2_gate_and_answer | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_EC_a-2_gate_only | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_EC_a-1_gate_and_answer | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_EC_a-1_gate_only | 0/6 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_EC_a-0.5_gate_and_answer | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_EC_a-0.5_gate_only | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_EC_a0_gate_and_answer | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_EC_a0_gate_only | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_EC_a0.5_gate_and_answer | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_EC_a0.5_gate_only | 3/6 | 3 | 1.0000 | 3 | {"das_E_simple_threshold": 3, "md_E_simple_threshold": 3} |
| md_EC_a1_gate_and_answer | 4/6 | 4 | 1.0000 | 4 | {"das_E_simple_threshold": 4, "md_E_simple_threshold": 4} |
| md_EC_a1_gate_only | 4/6 | 4 | 1.0000 | 4 | {"das_E_simple_threshold": 4, "md_E_simple_threshold": 4} |
| md_EC_a2_gate_and_answer | 5/6 | 5 | 1.0000 | 5 | {"das_E_simple_threshold": 5, "md_E_simple_threshold": 5} |
| md_EC_a2_gate_only | 5/6 | 5 | 1.0000 | 5 | {"das_E_simple_threshold": 5, "md_E_simple_threshold": 5} |

## qa

| 方法 | 实际回答 | 答对 | 已回答准确率 | 原模型简单筛题答对 | 固定E简单筛题答对 |
|---|---:|---:|---:|---:|---:|
| baseline | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_E | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_C_a-2_gate_and_answer | 0/3 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_C_a-2_gate_only | 0/3 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_C_a-1_gate_and_answer | 1/3 | 1 | 1.0000 | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_C_a-1_gate_only | 1/3 | 1 | 1.0000 | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_C_a-0.5_gate_and_answer | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_C_a-0.5_gate_only | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_C_a0_gate_and_answer | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_C_a0_gate_only | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_C_a0.5_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_C_a0.5_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_C_a1_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_C_a1_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_C_a2_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_C_a2_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_EC_a-2_gate_and_answer | 0/3 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_EC_a-2_gate_only | 0/3 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_EC_a-1_gate_and_answer | 1/3 | 1 | 1.0000 | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_EC_a-1_gate_only | 1/3 | 1 | 1.0000 | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| das_EC_a-0.5_gate_and_answer | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_EC_a-0.5_gate_only | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_EC_a0_gate_and_answer | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_EC_a0_gate_only | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_EC_a0.5_gate_and_answer | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_EC_a0.5_gate_only | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| das_EC_a1_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_EC_a1_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_EC_a2_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| das_EC_a2_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_E | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| md_C_a-2_gate_and_answer | 0/3 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_C_a-2_gate_only | 0/3 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_C_a-1_gate_and_answer | 1/3 | 1 | 1.0000 | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_C_a-1_gate_only | 1/3 | 1 | 1.0000 | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_C_a-0.5_gate_and_answer | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| md_C_a-0.5_gate_only | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| md_C_a0_gate_and_answer | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| md_C_a0_gate_only | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| md_C_a0.5_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_C_a0.5_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_C_a1_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_C_a1_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_C_a2_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_C_a2_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_EC_a-2_gate_and_answer | 0/3 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_EC_a-2_gate_only | 0/3 | 0 | — | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_EC_a-1_gate_and_answer | 1/3 | 1 | 1.0000 | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_EC_a-1_gate_only | 1/3 | 1 | 1.0000 | 0 | {"das_E_simple_threshold": 0, "md_E_simple_threshold": 0} |
| md_EC_a-0.5_gate_and_answer | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| md_EC_a-0.5_gate_only | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| md_EC_a0_gate_and_answer | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| md_EC_a0_gate_only | 2/3 | 1 | 0.5000 | 1 | {"das_E_simple_threshold": 1, "md_E_simple_threshold": 1} |
| md_EC_a0.5_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_EC_a0.5_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_EC_a1_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_EC_a1_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_EC_a2_gate_and_answer | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
| md_EC_a2_gate_only | 3/3 | 2 | 0.6667 | 2 | {"das_E_simple_threshold": 2, "md_E_simple_threshold": 2} |
