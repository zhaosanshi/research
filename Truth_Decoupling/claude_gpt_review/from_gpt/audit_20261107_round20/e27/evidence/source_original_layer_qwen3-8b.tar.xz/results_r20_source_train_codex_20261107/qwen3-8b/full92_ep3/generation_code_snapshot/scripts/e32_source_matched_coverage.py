#!/usr/bin/env python3
"""Equal actual-coverage diagnostics for the live-source generation experiments.

Every condition uses the same unmodified-model, mean answer-token log likelihood.
Only question and generated text enter this score. Actual substantive-answer
eligibility is measured offline by the reference-aware semantic grader; A/B
correctness never enters ordering. These are tuning diagnostics, not a newly
unseen test set. Original generation and grading files remain untouched.
"""
import argparse
from pathlib import Path

import torch

import common
import e25_qa_das as qa
import e27_qa_generation as source_loader
from core.experiment_provenance import implementation_identity, require_unchanged
from core.model_io import forward_logits
from core.qa_context import encode_answer, pack_answers, answer_logprobs
from core.qa_precision import fp32_output_projection
from core.qa_scoring import reference_answers
from core.selective_eval import evaluate_coverage

PROTOCOL = 'source_generation_equal_simple_coverage_v1'
COVERAGES = (.25, .5, .75)


def inputs(args):
    ns, meta, bank, prepared = source_loader.source_run(args.source_run)
    path = args.run_dir / (args.stem + '.json')
    raw = qa.read(path)
    questions = prepared['splits']['tune'][:3] if args.stem == 'check' else prepared['splits']['tune']
    names = raw.get('conditions')
    if (raw.get('completed') is not True or raw.get('split') != 'tune' or raw.get('model') != meta['model']
            or not isinstance(names, list) or not names or len(names) != len(set(names))
            or {s['name'] for s in raw['condition_specs']} != set(names)
            or [r['pair_id'] for r in raw['evaluations']] != [r['pair_id'] for r in questions]):
        raise ValueError('need complete same-model source-generation tuning cohort')
    if args.stem == 'tune' and (raw.get('pilot') or raw.get('wiring_pilot')):
        raise ValueError('a wiring pilot cannot be presented as a full tuning comparison')
    identity = raw['identity']
    if identity['source'] != source_loader.source_identity(ns, meta, [identity['layer']]):
        raise ValueError('generation source differs from the unmodified scoring model/source')
    qa.verify_question_rows([{**r, 'idx': i} for i, r in enumerate(raw['evaluations'])], questions)
    for row in raw['evaluations']:
        if set(row['outputs']) != set(names) or set(row['finished']) != set(names):
            raise ValueError('generation condition missing from a question')
        if any(not isinstance(row['outputs'][name], str) or type(row['finished'][name]) is not bool for name in names):
            raise ValueError('invalid generation text or completion flag')
    return ns, meta, prepared, raw, path


def score(args, bundle=None):
    ns, meta, prepared, raw, raw_path = inputs(args)
    code = implementation_identity(__file__)
    identity = {'protocol': PROTOCOL, 'source_generation_sha256': qa.digest(raw_path),
        'model': meta['model'], 'source': raw['identity']['source'], 'conditions': raw['conditions'],
        'question_ids': [r['pair_id'] for r in raw['evaluations']],
        'score': 'unmodified-model mean log probability of re-encoded generated answer tokens, no EOS',
        'input_fields': ['question', 'generated_answer'], 'uses_gold_in_score': False,
        'batch_size': 1, 'precision': 'float32 output projection, unchanged native backbone',
        'implementation': code, 'pilot': args.stem == 'check', 'exploratory_tuning_only': True}
    path = args.run_dir / (args.stem + '_simple_scores.json')
    out = qa.read(path) if path.exists() else {'identity': identity, 'rows': [], 'completed': False}
    if out['identity'] != identity:
        raise ValueError('score source/config/implementation changed; keep the old artifact and use a new directory')
    if [r['pair_id'] for r in out['rows']] != identity['question_ids'][:len(out['rows'])]:
        raise ValueError('score resume row order/identity changed')
    if out['completed']:
        if len(out['rows']) != len(raw['evaluations']):
            raise ValueError('completed score artifact is missing questions')
        return out
    if bundle is None:
        bundle = qa.open_bundle(meta, prepared)
    qa.verify_bundle(bundle, meta, prepared)
    versions = [(p, p._version) for p in bundle.model.parameters()]
    with fp32_output_projection(bundle):
        for record in raw['evaluations'][len(out['rows']):]:
            scores, unique = {}, {}
            for name in raw['conditions']:
                prediction = record['outputs'][name]
                if prediction not in unique:
                    value = -1e6
                    if prediction.strip():
                        item = encode_answer(bundle, meta['config']['qa_system'], record['question'], prediction,
                                             meta['config']['qa_user'])
                        if record.get('prompt_token_ids', {}).get('base') != item['prefix_ids']:
                            raise ValueError('scoring prompt differs from the original unmodified-model prompt')
                        packed = pack_answers([item], bundle.tokenizer.pad_token_id, bundle.device)
                        value = float(answer_logprobs(forward_logits(bundle, packed['inputs']), packed)[0]) / item['answer_length']
                        if not bool(torch.isfinite(torch.tensor(value))):
                            raise RuntimeError('nonfinite answer log likelihood')
                    unique[prediction] = value
                scores[name] = unique[prediction]
            out['rows'].append({'pair_id': record['pair_id'], 'scores': scores,
                                'unique_generated_strings_scored': len(unique)})
            if len(out['rows']) % 16 == 0:
                qa.save(path, out)
    if any(p._version != version for p, version in versions):
        raise RuntimeError('unmodified-model scorer changed model parameters')
    require_unchanged(code, __file__)
    out['completed'] = True
    qa.save(path, out)
    return out


def report(args):
    _, meta, _, raw, raw_path = inputs(args)
    score_path = args.run_dir / (args.stem + '_simple_scores.json')
    scored_path = args.run_dir / (args.stem + '_scored_items.json')
    scores, graded = qa.read(score_path), qa.read(scored_path)
    ids = [r['pair_id'] for r in raw['evaluations']]
    names = raw['conditions']
    if (scores.get('completed') is not True or scores['identity']['source_generation_sha256'] != qa.digest(raw_path)
            or scores['identity']['conditions'] != names or scores['identity']['question_ids'] != ids
            or [r['pair_id'] for r in scores['rows']] != ids):
        raise ValueError('score artifact is incomplete or foreign')
    if (graded.get('grading_completed') is not True or graded.get('completed') is not True
            or graded['grading_source_generation_sha256'] != qa.digest(raw_path)
            or [r['pair_id'] for r in graded['evaluations']] != ids or graded['conditions'] != names):
        raise ValueError('semantic grading is incomplete or foreign')
    arms = {name: [] for name in names}
    quality = {name: {'replacement_character': 0, 'unfinished': 0} for name in names}
    for original, row, score_row in zip(raw['evaluations'], graded['evaluations'], scores['rows']):
        if (row['outputs'] != original['outputs'] or row['finished'] != original['finished']
                or set(score_row['scores']) != set(names)):
            raise ValueError('graded answers or score condition set differ from raw generation')
        _, only_refusal = reference_answers(original['gold'])
        if row.get('gold_is_abstention') is not bool(only_refusal):
            raise ValueError('reference-only-refusal partition changed')
        for name in names:
            label = row['outcome'][name]
            if label not in ('correct', 'wrong', 'abstain') or label != row['judge'][name]['label']:
                raise ValueError('unresolved or inconsistent semantic grade')
            if only_refusal:
                continue
            arms[name].append({'id': str(row['pair_id']), 'pair_id': str(row['pair_id']),
                               'outcome': label, 'score': score_row['scores'][name]})
            quality[name]['replacement_character'] += '\ufffd' in row['outputs'][name]
            quality[name]['unfinished'] += not row['finished'][name]
        for a in names:
            for b in names:
                if original['outputs'][a] == original['outputs'][b] and (score_row['scores'][a] != score_row['scores'][b]
                                                                      or row['outcome'][a] != row['outcome'][b]):
                    raise ValueError('identical question/answer received different score or grade across conditions')
    comparison = evaluate_coverage(arms, COVERAGES, n_boot=args.n_boot, seed=42)
    result = {'protocol': PROTOCOL, 'model': meta['model'], 'pilot': args.stem == 'check',
        'exploratory_tuning_only': True, 'primary_quality': 'original semantic grades; malformed/unfinished counts separately shown',
        'source_files': {str(p.name): qa.digest(p) for p in (raw_path, score_path, scored_path)},
        'score_uses_gold': False, 'actual_answer_eligibility': 'reference-aware offline semantic refusal annotation; A/B both eligible',
        'natural': {name: {'n': len(rs), 'correct': sum(r['outcome'] == 'correct' for r in rs),
                          'answered': sum(r['outcome'] != 'abstain' for r in rs)} for name, rs in arms.items()},
        'quality': quality, 'matched_coverage': comparison}
    qa.save(args.run_dir / (args.stem + '_matched_coverage.json'), result)
    lines = ['# 真实来源交换：同实际作答率探索性比较', '', '全部来自调参集，不是新的确认性测试。',
             '所有组使用同一个未干预模型给生成答案打平均词分；实质作答由离线语义标注统计。', '']
    for point in comparison['coverages']:
        lines += ['## 目标 %.0f%%' % (point['target_coverage'] * 100), '',
                  '| 方法 | 实际回答 | 答对 | 已回答准确率 | 状态 |', '|---|---:|---:|---:|---|']
        for name, row in point['arms'].items():
            lines.append('| %s | %s | %s | %s | %s |' % (name, row.get('answered'), row.get('correct'),
                row.get('accuracy_answered'), '可行' if row['feasible'] else '实际回答不足'))
        lines.append('')
    (args.run_dir / (args.stem + '_matched_coverage.md')).write_text('\n'.join(lines))
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('phase', choices=('score', 'report'))
    p.add_argument('--source-run', type=Path, required=True)
    p.add_argument('--run-dir', type=Path, required=True)
    p.add_argument('--stem', choices=('check', 'tune'), default='tune')
    p.add_argument('--n-boot', type=int, default=2000)
    args = p.parse_args()
    if args.n_boot < 1:
        p.error('n-boot must be positive')
    if args.phase == 'score':
        score(args)
    else:
        report(args)


if __name__ == '__main__':
    main()
