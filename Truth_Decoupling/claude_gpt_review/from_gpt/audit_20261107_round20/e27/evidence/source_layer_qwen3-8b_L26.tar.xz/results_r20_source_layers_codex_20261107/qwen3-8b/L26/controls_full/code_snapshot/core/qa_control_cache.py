"""Copy a verified control cache into an independent run without changing labels."""
import hashlib
import json
import os
from pathlib import Path
import re

from .judge import qa_cache_key
from .qa_generation_adapter import digest
from .io_utils import atomic_json_dump


def seed_control_cache(*, source_dir, run_dir, judge_config, scored_rows, conditions,
                       scored_sha256, stem):
    if source_dir is None:
        raise ValueError('supply --controls-judge-cache for an independent copy of the original control judgments')
    filename = 'judge_cache_%s.jsonl' % re.sub(r'[^A-Za-z0-9_.-]', '_', judge_config['model'])
    source_cache = Path(source_dir) / filename
    target_cache = Path(run_dir) / 'judge_cache' / filename
    if source_cache.resolve() == target_cache.resolve():
        raise ValueError('evaluation must use an independent cache copy')
    source_bytes = source_cache.read_bytes()
    def entries(data):
        result = {}
        for line in data.decode().splitlines():
            if line.strip():
                row = json.loads(line); result[row['key']] = row
        return result
    source_entries = entries(source_bytes)
    for row in scored_rows:
        for condition in conditions:
            key = qa_cache_key(judge_config['model'], row['question'], row['judge_reference_answers'],
                               row['outputs'][condition], row.get('incorrect') or None)
            cached = source_entries.get(key, {})
            match = re.match(r'\s*\**\s*([ABC])\b', cached.get('answer', ''))
            label = {'A': 'correct', 'B': 'wrong', 'C': 'abstain'}.get(match.group(1)) if match else None
            if label != row['judge'][condition]['label']:
                raise ValueError('control cache is missing or differs from its recorded grade: ' + row['pair_id'])
    target_entries = entries(target_cache.read_bytes()) if target_cache.exists() else {}
    added = 0
    for key, row in source_entries.items():
        if key in target_entries and target_entries[key]['answer'] != row['answer']:
            raise ValueError('cache collision would change an existing grade; do not overwrite it')
        if key not in target_entries: target_entries[key] = row; added += 1
    target_cache.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(str(target_cache) + '.tmp')
    temporary.write_text(''.join(json.dumps(target_entries[k], ensure_ascii=False) + '\n' for k in sorted(target_entries)))
    os.replace(temporary, target_cache)
    atomic_json_dump({'source_cache': str(source_cache), 'source_cache_sha256': hashlib.sha256(source_bytes).hexdigest(),
                     'target_cache': str(target_cache), 'target_cache_sha256_after_merge': digest(target_cache),
                     'source_entries': len(source_entries), 'added_entries': added,
                     'control_scored_items_sha256': scored_sha256},
                    str(Path(run_dir) / (stem + '_judge_cache_seed.json')))
    return {'judge_cache_dir': str(target_cache.parent), 'frozen_control_source_sha256': scored_sha256,
            'frozen_control_grades': {r['pair_id']: {c: r['judge'][c] for c in conditions} for r in scored_rows}}
