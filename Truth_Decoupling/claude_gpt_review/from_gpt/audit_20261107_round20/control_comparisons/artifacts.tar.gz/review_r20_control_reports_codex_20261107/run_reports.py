from pathlib import Path
import json,subprocess,sys,time
root=Path('/workspace/Truth_Decoupling');model=sys.argv[1]
base=root/'review_r20_control_reports_codex_20261107';code=base/'code'
jobs=[root/'results_r20_norm_random_codex_20261107'/model/'full192',root/'results_source_question_mask_codex_20261107'/model/'full92_ep3']
if model=='qwen3-8b':jobs += [root/'results_e34_completion_codex_20261107'/model/'uniform256',root/'results_source_question_mask_codex_20261107'/model/'uniform256']
for directory in jobs:
 deadline=time.time()+1800
 while True:
  try:
   g=json.loads((directory/'tune_scored_items.json').read_text());s=json.loads((directory/'tune_simple_scores.json').read_text())
   if g.get('grading_completed') is True and s.get('completed') is True:break
  except (FileNotFoundError,json.JSONDecodeError):pass
  if time.time()>deadline:raise TimeoutError(str(directory))
  time.sleep(3)
 args=[sys.executable,str(code/'scripts/e32_source_matched_coverage.py'),'report','--source-run',str(root/'results_qa_das_v1u'/model/'full'),'--run-dir',str(directory),'--n-boot','2000']
 with (directory/'tune_matched_coverage.log').open('w') as f:rc=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT).returncode
 (directory/'tune_matched_coverage.exit').write_text(str(rc)+'\n')
 if rc:raise SystemExit(rc)
 print('reported',directory,flush=True)
