from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/workspace/Truth_Decoupling');model=sys.argv[1]
base=root/'review_r20_control_scoring_codex_20261107'
code=base/'code'
sys.path[:0]=[str(code/'scripts'),str(code)]
import e25_qa_das as qa
jobs=[root/'results_r20_norm_random_codex_20261107'/model/'full192',root/'results_source_question_mask_codex_20261107'/model/'full92_ep3']
if model=='qwen3-8b':jobs += [root/'results_e34_completion_codex_20261107'/model/'uniform256',root/'results_source_question_mask_codex_20261107'/model/'uniform256']
source=root/'results_qa_das_v1u'/model/'full'
for directory in jobs:
 raw=qa.read(directory/'tune.json')
 assert raw['completed'] is True
 pilot=base/'pilots'/model/(directory.parent.parent.name+'_'+directory.name);pilot.mkdir(parents=True,exist_ok=True)
 child=json.loads(json.dumps(raw));child['evaluations']=child['evaluations'][:3]
 child['identity']['question_ids']=[r['pair_id'] for r in child['evaluations']]
 child['pilot']=child['wiring_pilot']=True;child['scoring_subset_only']=True
 child['scoring_subset_parent_sha256']=qa.digest(directory/'tune.json')
 child['protocol_fingerprint']=child['bank_protocol_fingerprint']=qa.fingerprint(child['identity'])
 qa.save(pilot/'check.json',child)
 args=[sys.executable,str(code/'scripts/e32_source_matched_coverage.py'),'score','--source-run',str(source)]
 for run,stem in ((pilot,'check'),(directory,'tune')):
  log=run/(stem+'_simple_scores.log')
  with log.open('w') as f:
   result=subprocess.run(args+['--run-dir',str(run),'--stem',stem],stdout=f,stderr=subprocess.STDOUT)
  (run/(stem+'_simple_scores.exit')).write_text(str(result.returncode)+'\n')
  if result.returncode:raise SystemExit(result.returncode)
  scored=qa.read(run/(stem+'_simple_scores.json'));assert scored['completed'] and len(scored['rows'])==(3 if stem=='check' else 192)
 print('scored',directory,flush=True)
