# E26 同实际作答率方法比较

精确配额表是批量筛题评估；排序不看正确性。冻结门槛表另报真实测试作答率。
QA分母为固定实质参考题；不够配额标不可行，未决判分不出表。

PILOT ONLY — 线路检查，不作效果结论。

## tf / 目标 25%

| 方法 | 实际回答 | 答对 | 已回答准确率 | 状态 |
|---|---:|---:|---:|---|
| baseline_commitment | 1/6 | 1 | 1.0000 | 可行 |
| baseline_simple | 1/6 | 1 | 1.0000 | 可行 |
| baseline_random | 1/6 | 1 | 1.0000 | 可行 |
| das_E | 1/6 | 1 | 1.0000 | 可行 |
| das_C | 1/6 | 1 | 1.0000 | 可行 |
| das_EC | 1/6 | 1 | 1.0000 | 可行 |
| md_E | 1/6 | 1 | 1.0000 | 可行 |
| md_C | 1/6 | 1 | 1.0000 | 可行 |
| md_EC | 1/6 | 1 | 1.0000 | 可行 |
| das_E_simple | 1/6 | 1 | 1.0000 | 可行 |
| das_C_simple | 1/6 | 1 | 1.0000 | 可行 |
| md_E_simple | 1/6 | 1 | 1.0000 | 可行 |
| md_C_simple | 1/6 | 1 | 1.0000 | 可行 |

## tf / 目标 50%

| 方法 | 实际回答 | 答对 | 已回答准确率 | 状态 |
|---|---:|---:|---:|---|
| baseline_commitment | 3/6 | 3 | 1.0000 | 可行 |
| baseline_simple | 3/6 | 3 | 1.0000 | 可行 |
| baseline_random | 3/6 | 3 | 1.0000 | 可行 |
| das_E | 3/6 | 3 | 1.0000 | 可行 |
| das_C | 3/6 | 3 | 1.0000 | 可行 |
| das_EC | 3/6 | 3 | 1.0000 | 可行 |
| md_E | 3/6 | 3 | 1.0000 | 可行 |
| md_C | 3/6 | 3 | 1.0000 | 可行 |
| md_EC | 3/6 | 3 | 1.0000 | 可行 |
| das_E_simple | 3/6 | 3 | 1.0000 | 可行 |
| das_C_simple | 3/6 | 3 | 1.0000 | 可行 |
| md_E_simple | 3/6 | 3 | 1.0000 | 可行 |
| md_C_simple | 3/6 | 3 | 1.0000 | 可行 |

## tf / 目标 75%

| 方法 | 实际回答 | 答对 | 已回答准确率 | 状态 |
|---|---:|---:|---:|---|
| baseline_commitment | 4/6 | 4 | 1.0000 | 可行 |
| baseline_simple | 4/6 | 4 | 1.0000 | 可行 |
| baseline_random | 4/6 | 4 | 1.0000 | 可行 |
| das_E | 4/6 | 4 | 1.0000 | 可行 |
| das_C | 4/6 | 4 | 1.0000 | 可行 |
| das_EC | 4/6 | 4 | 1.0000 | 可行 |
| md_E | 4/6 | 4 | 1.0000 | 可行 |
| md_C | 4/6 | 4 | 1.0000 | 可行 |
| md_EC | 4/6 | 4 | 1.0000 | 可行 |
| das_E_simple | 4/6 | 4 | 1.0000 | 可行 |
| das_C_simple | 4/6 | 4 | 1.0000 | 可行 |
| md_E_simple | 4/6 | 4 | 1.0000 | 可行 |
| md_C_simple | 4/6 | 4 | 1.0000 | 可行 |

## qa / 目标 25%

| 方法 | 实际回答 | 答对 | 已回答准确率 | 状态 |
|---|---:|---:|---:|---|
| baseline_commitment | 0/3 | 0 | — | 可行 |
| baseline_simple | 0/3 | 0 | — | 可行 |
| baseline_random | 0/3 | 0 | — | 可行 |
| das_E | 0/3 | 0 | — | 可行 |
| das_C | 0/3 | 0 | — | 可行 |
| das_EC | 0/3 | 0 | — | 可行 |
| md_E | 0/3 | 0 | — | 可行 |
| md_C | 0/3 | 0 | — | 可行 |
| md_EC | 0/3 | 0 | — | 可行 |
| das_E_simple | 0/3 | 0 | — | 可行 |
| das_C_simple | 0/3 | 0 | — | 可行 |
| md_E_simple | 0/3 | 0 | — | 可行 |
| md_C_simple | 0/3 | 0 | — | 可行 |

## qa / 目标 50%

| 方法 | 实际回答 | 答对 | 已回答准确率 | 状态 |
|---|---:|---:|---:|---|
| baseline_commitment | 1/3 | 0 | 0.0000 | 可行 |
| baseline_simple | 1/3 | 0 | 0.0000 | 可行 |
| baseline_random | 1/3 | 0 | 0.0000 | 可行 |
| das_E | 1/3 | 0 | 0.0000 | 可行 |
| das_C | 1/3 | 0 | 0.0000 | 可行 |
| das_EC | 1/3 | 0 | 0.0000 | 可行 |
| md_E | 1/3 | 0 | 0.0000 | 可行 |
| md_C | 1/3 | 0 | 0.0000 | 可行 |
| md_EC | 1/3 | 0 | 0.0000 | 可行 |
| das_E_simple | 1/3 | 0 | 0.0000 | 可行 |
| das_C_simple | 1/3 | 0 | 0.0000 | 可行 |
| md_E_simple | 1/3 | 0 | 0.0000 | 可行 |
| md_C_simple | 1/3 | 0 | 0.0000 | 可行 |

## qa / 目标 75%

| 方法 | 实际回答 | 答对 | 已回答准确率 | 状态 |
|---|---:|---:|---:|---|
| baseline_commitment | — | — | — | 无法填满配额：insufficient_actual_answers |
| baseline_simple | — | — | — | 无法填满配额：insufficient_actual_answers |
| baseline_random | — | — | — | 无法填满配额：insufficient_actual_answers |
| das_E | — | — | — | 无法填满配额：insufficient_actual_answers |
| das_C | — | — | — | 无法填满配额：insufficient_actual_answers |
| das_EC | — | — | — | 无法填满配额：insufficient_actual_answers |
| md_E | — | — | — | 无法填满配额：insufficient_actual_answers |
| md_C | — | — | — | 无法填满配额：insufficient_actual_answers |
| md_EC | — | — | — | 无法填满配额：insufficient_actual_answers |
| das_E_simple | — | — | — | 无法填满配额：insufficient_actual_answers |
| das_C_simple | — | — | — | 无法填满配额：insufficient_actual_answers |
| md_E_simple | — | — | — | 无法填满配额：insufficient_actual_answers |
| md_C_simple | — | — | — | 无法填满配额：insufficient_actual_answers |
