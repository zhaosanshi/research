# E44 judge-free summary (pilot included)

## Explicit factor assignments (different pairs are different hypotheses)

| family | layer | low truth level | high truth level |
|---|---|---|---|
| C | 16 | none | E1 |
| E | 16 | none | E1 |

## training (loss per answer token; held-out questions never received a gradient)

| family | layer | gap | md norm | cos(w, md) | cause: no write / whole diff / md / trained | isolate: md / trained | held-out cause: no write / md / trained | held-out isolate: md / trained |
|---|---|---|---|---|---|---|---|---|
| C | 16 | 0.090 | 2.238 | 0.0402 | 0.0204 / 0.0202 / 0.0225 / 0.0197 | 0.0004 / 0.0001 | 0.2058 / 0.1700 / 0.2056 | 0.0002 / 0.0000 |
| E | 16 | 0.053 | 1.461 | 0.0364 | 0.0125 / 0.0099 / 0.0113 / 0.0123 | 0.0011 / 0.0001 | 0.0181 / 0.0136 / 0.0178 | 0.0002 / 0.0000 |

## generation

| family | layer | arm | split | n | changed | refusals | sentence-end | words | = target prompt (base =) | write/‖h‖ |
|---|---|---|---|---|---|---|---|---|---|---|
| C | 16 | caut.wq.m1 | train | 3 | 0 | 1 → 1 | 3 → 3 | 3.3 → 3.3 | 1 (1) | 0.009 |
| C | 16 | conf.dq.p1 | train | 3 | 3 | 0 → 0 | 3 → 3 | 2.3 → 2.7 | 0 (1) | 0.274 |
| C | 16 | conf.iso.p1 | train | 3 | 0 | 0 → 0 | 3 → 3 | 2.3 → 2.3 | 3 (3) | 0.003 |
| C | 16 | conf.wq.p1 | train | 3 | 0 | 0 → 0 | 3 → 3 | 2.3 → 2.3 | 1 (1) | 0.009 |
| C | 16 | conf_E1.wq.p1 | train | 3 | 1 | 0 → 0 | 3 → 3 | 3.0 → 2.3 | 0 (0) | 0.008 |
| C | 16 | x.md.p1 | train | 3 | 1 | 1 → 1 | 3 → 3 | 3.3 → 3.0 | — | 0.220 |
| C | 16 | x.rand.p1 | train | 3 | 0 | 1 → 1 | 3 → 3 | 3.3 → 3.3 | — | 0.009 |
| C | 16 | x.w.m1 | train | 3 | 0 | 1 → 1 | 3 → 3 | 3.3 → 3.3 | — | 0.009 |
| C | 16 | x.w.p1 | train | 3 | 0 | 1 → 1 | 3 → 3 | 3.3 → 3.3 | — | 0.009 |
| E | 16 | caut.wq.p1 | train | 3 | 0 | 1 → 1 | 3 → 3 | 3.3 → 3.3 | — | 0.003 |
| E | 16 | conf.dq.p1 | train | 3 | 1 | 0 → 0 | 3 → 3 | 2.3 → 2.7 | 2 (1) | 0.181 |
| E | 16 | conf.iso.p1 | train | 3 | 0 | 0 → 0 | 3 → 3 | 2.3 → 2.3 | 3 (3) | 0.002 |
| E | 16 | conf.wq.p1 | train | 3 | 0 | 0 → 0 | 3 → 3 | 2.3 → 2.3 | 1 (1) | 0.004 |
| E | 16 | conf_E1.wq.m1 | train | 3 | 1 | 0 → 0 | 3 → 3 | 3.0 → 2.3 | 1 (1) | 0.004 |
| E | 16 | x.md.p1 | train | 3 | 1 | 1 → 1 | 3 → 3 | 3.3 → 2.7 | — | 0.143 |
| E | 16 | x.rand.p1 | train | 3 | 0 | 1 → 1 | 3 → 3 | 3.3 → 3.3 | — | 0.005 |
| E | 16 | x.w.p1 | train | 3 | 0 | 1 → 1 | 3 → 3 | 3.3 → 3.3 | — | 0.005 |

## reference ranking (max-true margin / any-true top1 are not standard MC1) and log p("I don't know.")

| family | layer | arm | split | scored | any-true top1 | MC2 | max-true margin change | to correct / to wrong | log p(abstain) change |
|---|---|---|---|---|---|---|---|---|---|
| — | — | no write, caut | train | 3 | 1.0000 | 0.9658 | — | — | (level -8.3347) |
| — | — | no write, caut_E1 | train | 3 | 1.0000 | 0.9901 | — | — | (level -7.8237) |
| — | — | no write, caut_E2 | train | 3 | 1.0000 | 0.9893 | — | — | (level -7.7665) |
| — | — | no write, caut_M | train | 3 | 0.3333 | 0.4299 | — | — | (level -7.7883) |
| — | — | no write, conf | train | 3 | 0.6667 | 0.6437 | — | — | (level -24.3411) |
| — | — | no write, conf_E1 | train | 3 | 0.6667 | 0.7803 | — | — | (level -23.2425) |
| — | — | no write, conf_E2 | train | 3 | 0.6667 | 0.7554 | — | — | (level -21.7649) |
| — | — | no write, conf_M | train | 3 | 0.3333 | 0.4108 | — | — | (level -20.0074) |
| — | — | no write, x | train | 3 | 1.0000 | 0.9643 | — | — | (level -8.2372) |
| — | — | no write, x_E1 | train | 3 | 1.0000 | 0.9909 | — | — | (level -7.8848) |
| — | — | no write, x_F | train | 3 | 1.0000 | 0.9985 | — | — | (level -9.2452) |
| C | 16 | conf.iso.p1 | train | 3 | 0.6667 | 0.6448 | -0.0185 | 0 / 0 | -0.0223 |
| C | 16 | conf.wq.p1 | train | 3 | 0.6667 | 0.6437 | 0.0357 | 0 / 0 | -0.0420 |
| C | 16 | x.rand.p1 | train | 3 | 1.0000 | 0.9682 | 0.0375 | 0 / 0 | 0.0073 |
| C | 16 | x.w.p1 | train | 3 | 1.0000 | 0.9664 | 0.0743 | 0 / 0 | 0.0065 |
| E | 16 | conf.iso.p1 | train | 3 | 0.6667 | 0.6452 | 0.0222 | 0 / 0 | -0.0433 |
| E | 16 | conf.wq.p1 | train | 3 | 0.6667 | 0.6453 | 0.0315 | 0 / 0 | 0.0277 |
| E | 16 | x.rand.p1 | train | 3 | 1.0000 | 0.9664 | 0.0139 | 0 / 0 | 0.0028 |
| E | 16 | x.w.p1 | train | 3 | 1.0000 | 0.9678 | 0.0699 | 0 / 0 | 0.0037 |
